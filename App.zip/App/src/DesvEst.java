
import static java.lang.Math.pow;
import static java.lang.Math.sqrt;
import java.util.*;

/**
 * @author Efrain
 */
public class DesvEst {

    /**
     * Default constructor
     */
    public DesvEst() {
    }

    /**
     * @param media 
     * @param dataList 
     * @param n 
     * @return
     */
    public double getDesvEstd(double media, String[] dataList, double n) {
        // TODO implement here
//        int datalist[]={186, 699, 132, 272, 291, 331, 199, 1890, 788, 1601};
//        Media me=new Media();
        double suma=0;
        for (int x = 0; x < dataList.length; x++) {
			suma = (double) (suma + (pow((Double.parseDouble(dataList[x])- media),2)));
                }
        double d = (suma/(n-1));
        double des = sqrt(d);
        
        
        return des;
    }

}